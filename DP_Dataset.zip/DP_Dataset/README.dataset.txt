# Dark Patterns > 2024-01-27 7:09pm
https://universe.roboflow.com/ankit-bhardwaj-auu8v/dark-patterns-i2yqu

Provided by a Roboflow user
License: CC BY 4.0

